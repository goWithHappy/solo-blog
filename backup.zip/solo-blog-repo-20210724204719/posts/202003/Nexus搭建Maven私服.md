title: Nexus搭建Maven私服
date: '2020-03-07 15:34:55'
updated: '2020-04-28 21:18:32'
tags: [java, 工具, 教程]
permalink: /build_nexus
---
![](https://img.hacpai.com/bing/20190628.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Nexus 的概述

引用百度百科一段话

> `Nexus` 是一个强大的 Maven 仓库管理器，它极大地简化了自己内部仓库的维护和外部仓库的访问。利用 `Nexus` 你可以只在一个地方就能够完全控制访问 和部署在你所维护仓库中的每个 Artifact。`Nexus` 是一套“开箱即用”的系统不需要数据库，它使用文件系统加 Lucene 来组织数据。Nexus 使用 ExtJS 来开发界面，利用 Restlet 来提供完整的 REST APIs，通过 m2eclipse 与 Eclipse 集成使用。Nexus 支持 WebDAV 与 LDAP 安全身份认证。

简而言之，`Nexus` 是搭建 `Maven` 私服管理 `Maven` 仓库的工具。

好，废话不多说，下边我们开始着手搭建 Nexus。

# Nexus 安装与部署

## Nexus 在 Windows 上安装与使用

### 安装

首先安装之前电脑上已经安装好了 JDK 环境，并且添加好了环境变量

第一步，从官网上下载软件包（[点这里](http://www.sonatype.com/download-oss-sonatype)）

第二步，解压到自定义的非中文目录中

第三步，启动 nexus，进入安装目录进入 `nexus-2.12.0-01\bin\jsw` 目录下根据自己的系统选择自己电脑的版本。

![image.png](https://img.hacpai.com/file/2020/04/image-580b3b47.png)


第四步，注册服务运行 `install-nexus.bat` 在系统中注册服务。

```
注意：
```

`uninstall-nexus.bat` 表示卸载服务

第五步，启动 Nexus,注册后可以通过 `start-nexus.bat/stop-nexus.bat ` 开启服务和关闭服务

### 使用

1. 在浏览器输入   http://localhost:8081/nexus 进入主界面

   ![image.png](https://img.hacpai.com/file/2020/04/image-e2cd2d44.png)
2. 在主界面右上角 log in 进行登录，默认用户名和密码是
   用户名：admin
   密码：admin123
3. 如果想更多端口可以在 `nexus-2.12.0-01\conf\` 目录中更改 `nexus.properties`

![image.png](https://img.hacpai.com/file/2020/04/image-bf16e8f7.png)


## Nexus 在 Linux 上安装与使用

Nexus 在 Linux 上边的安装过程和在 Windows 上边是类似的，或者说更简单，这里就不再赘述了。
