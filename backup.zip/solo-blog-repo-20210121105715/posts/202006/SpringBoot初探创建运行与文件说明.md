title: SpringBoot初探：创建运行与文件说明
date: '2020-06-18 16:41:28'
updated: '2020-06-18 16:41:28'
tags: [SpringBoot, 教程, java]
permalink: /hello-spring-boot
---
![](https://b3logfile.com/bing/20190406.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

本系列文章主要讲的是本人在阅读《Spring Boot In Action》过程中的总结的要点或者说是笔记，其中本文是第一篇，主要讲述的是Spring Boot项目的创建、运行以及文件说明。

# 项目创建

一般来说，初始化一个SpringBoot项目方式好多种：

1. 通过SpringBoot 官方提供的Web页面：http://start.spring.io
2. 借助IDE（如IntelliJ IDEA）来创建
3. 通过使用curl命令下载一个官方的Demo程序
4. 通过Spring Tool Suite来创建

本文主要介绍前两种常用的创建方式

## 通过官方Web页面创建SpringBoot项目

1. 在线创建是SpringBoot官方提供的一种创建方式，浏览器中打开如下链接：

   http://start.spring.io
2. 在打开的页面中我们可以选择项目的构建工具是 Maven 还是 Gradle、语言是 Java 还是其它、要使用的 Spring Boot 版本号、项目的组织 Id（包名）、模块名称以及项目的依赖。

![image-20200618142507794](https://b3logfile.com/file/2020/06/solofetchupload1940541000921670940-1620ce53.png)

由于我开发的是SpringWeb应用因此，要选择Web。而Spring Boot DevTools是Spring官方提供的一种开发工具，可以实现热部署，持续集成等功能，建议也勾选上。

3. 填写完成之后点击`CTRL+ENTER`会自动下载一个Maven项目压缩包。

   解压后倒入到制定的IDE即可。

## 通过IntelliJ IDEA来创建一个SpringBoot项目

1. 创建项目时选择 **Spring Initializr**

![image-20200618143447156](https://b3logfile.com/file/2020/06/solofetchupload1848845507464326845-3dbedcad.png)

2. 接着输入项目的基本信息，包括组织 Id、模块名称、项目构建类型、最终生成包的类型、Java 的版本、开发语言、项目版本号、项目描述以及项目的包。

   ![image-20200618144045631](https://b3logfile.com/file/2020/06/solofetchupload4517506396853824923-cf390aa4.png)
3. 接着选择项目所需要的依赖，之后IDEA会自动在pom.xml文件中添加对应的依赖。

![image-20200618145917084](https://b3logfile.com/file/2020/06/solofetchupload8125650813571033099-f09e184f.png)

4. 最后一步选择项目的路径以及名称，点击`Finish`后 一个SpringBoot项目便创建成功了。

   ![image-20200618150151394](https://b3logfile.com/file/2020/06/solofetchupload117141312239835248-7b6dd37c.png)

# 项目运行

项目创建完成之后，我们可以尝试运行一下，来看下效果。

简单来说运行一个SpringBoot项目的方式有两种：

1. 通过Maven运行
2. 运行main函数

## 通过Maven运行

1. 打开终端，执行如下Maven命令运行项目：

   ```shell
   mvn spring-boot:run
   ```
2. 启动完成后终端会显示如下信息：

   ![image-20200618152513735](https://b3logfile.com/file/2020/06/solofetchupload3553519014865639350-a04e5c5f.png)
3. 在浏览器中输入http://localhost:8080/  将出现如下界面

   ![image-20200618152641526](https://b3logfile.com/file/2020/06/solofetchupload3326910649352792447-2d0c1517.png)

## 运行main函数

1. 在 Intellij IDEA 中右键点击 `App 类`，然后点击 **run** 按钮即可启动项目。

   ![image-20200618152821017](https://b3logfile.com/file/2020/06/solofetchupload2128864342415351933-c778da17.png)
2. 启动完成后终端会显示如下信息：

   ![image-20200618152513735](https://b3logfile.com/file/2020/06/solofetchupload3553519014865639350-a04e5c5f.png)

# 各部分文件说明

## 项目结构

项目创建完成之后，可以看到一个SpringBoot项目具有如下结构：

![image-20200618153523372](https://b3logfile.com/file/2020/06/solofetchupload4057691813482319875-32c8a11e.png)

简单来说我们可以将SpringBoot项目与一个典型的Maven项目或者Gradle项目结构非常类似，其中java源代码放到`src/main/java`目录下边，测试代码放到`src/test/java`目录下面，资源文件（如html文件）放置到`/src/main/resources`目录下。

除了上边三项内容我们可以发现，项目中还有如下内容：

1. `mvnw` 和`mvnw.cmd`---Maven Wrapper的缩写。因为我们安装Maven时，默认情况下，系统所有项目都会使用全局安装的这个Maven版本。但是，对于某些项目来说，它可能必须使用某个特定的Maven版本，这个时候，就可以使用Maven Wrapper，它可以负责给这个特定的项目安装指定版本的Maven，而其他项目不受影响。
2. `pom.xml`---maven项目的依赖文件，用来描述项目的依赖。
3. `TaocoCloudApplication.java`---启动Spring boot项目的主类，通过调用该类的main方法可以启动Spring Boot项目。
4. `application.properties`---该文件在项目创建之初是空的，但是我们可以通过在该文件中设置某些特殊属性值，从而达到项目的特殊要求。
5. static---该目录用来放置任何的静态文件内容（图片，css文件，js文件等），项目初始化的时候为空。
6. templates---该目录用来防止模板文件。
7. `TacoCloudApplicationTests.java`---一个简单的测试类保证 TaoCloudApplication可以成功运行。
