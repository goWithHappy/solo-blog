title: 修改commit记录的常用方法
date: '2020-05-25 12:14:17'
updated: '2020-06-02 20:29:53'
tags: [git, 工具, 教程]
permalink: /change-commit
---
![](https://b3logfile.com/bing/20200226.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

在我们日常使用git的过程中难免会出现`commit`提交有问题的情况，因此我将自己在日常开发过程中常用的修改commit的方法总结如下。

# 修改commit历史

我们假设这样一个场景，程序员小吴创建了一个文本如下所示：
![test](https://b3logfile.com/file/2020/05/solofetchupload2556688517141753135-1ccef981.png)

在没有仔细检查的情况下进行了一次提交：
![第一次提交](https://b3logfile.com/file/2020/05/solofetchupload4538079778691529021-e9007b62.png)

然后此时小吴看到自己原来犯了一个低级错误写成了“1+1=1”，这太尴尬了，马上着手开始修改。

![天若OCR_202005240972907SS](https://b3logfile.com/file/2020/05/solofetchupload1910191777595210756-a81768d1.png)

修改完成之后，此时他就犯迷糊了：“如果直接提交是可以直接修改这个错误，但同时会有commit记录，万一被人发现这个小错误多尴尬。我吴某人一世英名可不能毁于一次commit呀”。此时小吴开始网上搜集资料去解决这个问题，他很容易找到了第一种解决方法。

## 在commit时通过添加--amend参数进行修改

小吴思考之后执行了如下命令:

```shell
git add test.txt
git commmit --amend -m "第二次正常提交"
```

![amend修改](https://b3logfile.com/file/2020/05/solofetchupload4165831273830703333-4527c6fd.png)

此时他通过`git log --graph`命令查看提交历史，果然第一次提交历史没有了。小吴很开心，继续很happy的写代码，但是写了一段时间之后，发现其实`添加空格`那次commit操作记录是没必要存在的。如果还是刚才的方法显然没法改此次commit记录。

![](https://b3logfile.com/file/2020/05/solofetchupload3243458146582764632-4c379001.png)

因此小吴又走上了艰苦卓越的查找资料之路，功夫不负有心人，小吴终于找到了他想要的解决方法。

# 通过git rebase -i 命令将多次提交合并成一次提交

因此，小吴执行了如下命令

```shell
# HEAD~2表示HEAD前两次的提交，该例子指的是从coomit id为ba9bb257
# 因为该命令在更改是必须给出想要修改的最近一次提交的父提交作为参数
# 命令等价于
# git reabse -i ba9bb257
git rebase -i HEAD~2
```

执行结果如下：

下边注释部分给出的是修改的命令格式写法。

由于我们是不想要添加一个空格这种commit记录的因此我们需要通过drop策略来删除此次commit历史。

修改后的内容如下：

![](https://b3logfile.com/file/2020/05/solofetchupload8248176425416247362-ddf04e47.png)

保存后弹出新的界面如下：

![](https://b3logfile.com/file/2020/05/solofetchupload6376301868693221136-a9459404.png)

删除“添加空格这一行”，然后保留“增加1+2”这一行。

![](https://b3logfile.com/file/2020/05/solofetchupload3898263463980956366-ed7e8819.png)

保存退出。查看提交记录：

![](https://b3logfile.com/file/2020/05/solofetchupload6959624068542586594-d1c4db37.png)

# 总结

本文主要总结了常用的修改commit记录的两种方法，当然可能不太全面。欢迎各位小伙伴补充，谢谢！！
