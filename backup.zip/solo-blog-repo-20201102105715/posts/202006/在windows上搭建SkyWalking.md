title: 在windows上搭建SkyWalking
date: '2020-06-03 19:29:31'
updated: '2020-06-03 19:29:31'
tags: [SkyWalking, 工具, 教程]
permalink: /build-skywalking-in-windows
---
![](https://b3logfile.com/bing/20200218.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

`skywalking`是一个开源的观测平台, 用于从服务和云原生基础设施收集, 分析, 聚合以及可视化数据.。可能大部分情况下该平台是安装在`linux`系统上，但如果要在本地开发的话可能免不了要在windows系统下安装。

# 安装须知

1. 安装之前请确保被监控的服务器上的系统时间和`OAP`服务器上的系统时间是相同的。
2. `JDK 8`
3. 本教程只适合运行`Skywalking`的`Backend`和`UI`来进行预览或演示，可能并不适合长期部署使用。如果需要在生产环境使用，请参考下边三个官方文档，进行进一步设置：
   1. [Backend setup document](https://github.com/apache/skywalking/blob/v7.0.0/docs/en/setup/backend/backend-setup.md)
   2. [UI setup document](https://github.com/apache/skywalking/blob/v7.0.0/docs/en/setup/backend/ui-setup.md)
   3. [CLI set up document](https://github.com/apache/skywalking-cli)

# 第一步 下载软件包

Java Agent、后端、UI包含在官方的发行版本中，可以在相对应的Apache官方网站下载：[戳我:point_left:](http://skywalking.apache.org/downloads/)

![](https://b3logfile.com/file/2020/06/solofetchupload3103123531442560310-836df222.png)

# 第二步 启动后端

点击bin目录中的`startup.bat`便会启动收集端程序和UI，具体文件如下：

![](https://b3logfile.com/file/2020/06/solofetchupload8019326446466930173-b529ec69.png)

同时关于SkyWalking的一些简单知识我们需要知道：

1. 由于`SkyWalking`默认使用H2存储，因此如果只是简单使用就无需部署其他数据库。
2. Backend的gRPC相关的API可访问`0.0.0.0/11800`，rest相关的API可访问`0.0.0.0/12800`。 在Java，.NetCore，Node.js， Istio agents/probe中，设置gRPC服务地址为`ip/host:11800`。 (ip/host填写Backend暴露的)
3. UI 监听`8080` 端口,同时请求`127.0.0.1/12800`来做GraphQL查询。

通过上面的说明我们可以知道，**如果部署成功后**我们可以通过访问`htttp://127.0.0.1:8080`来访问UI界面。

点击start之后首先会弹出下边两个窗口：

![](https://b3logfile.com/file/2020/06/solofetchupload224111731643575055-48fe9fe3.png)

在浏览器中输入上述地址(`htttp://127.0.0.1:8080`)，出现如下界面，则证明部署成功：

![](https://b3logfile.com/file/2020/06/solofetchupload2139062705823697335-e6c9fc02.png)

由于还没有指定所以UI上边是没有界面。

# 指定探针

该步需要根据自己需求来设置探针，以监控tomcat为例：

修改`tomcat/bin/catalina.bat`的第一行：

`set "CATALINA_OPTS=-javaagent:path\apache-skywalking-apm-bin\agent\skywalking-agent.jar"`

**注意**：path替换成`SkyWalking`在本地安装路径。

以我的电脑为例：
![](https://b3logfile.com/file/2020/06/solofetchupload2355666115062582842-7f94d6a3.png)

然后启动tomcat，在浏览器访问tomcat的管理路径（localhost:8080），然后就可以在UI界面上看到数据访问的记录。界面如下：

![](https://b3logfile.com/file/2020/06/solofetchupload6474273157204909160-6220b0e0.png)

至此安装完成。

## 后记

未来一段时间按照计划要开发`Skywalking`插件，因此关于`SkyWalking`会建立起一个专题集合，详细记录自己在开发插件过程中踩到的坑，以及学习的心得。该篇博客是第一篇主要是关于`skywalking`个人PC环境搭建部分的内容。

# 参考

https://github.com/SkyAPM/document-cn-translation-of-skywalking/blob/master/docs/zh/master/setup/README.md

https://github.com/SkyAPM/document-cn-translation-of-skywalking/blob/master/docs/zh/master/setup/service-agent/java-agent/README.md

https://github.com/SkyAPM/document-cn-translation-of-skywalking/blob/master/docs/zh/master/setup/backend/backend-ui-setup.md
