title: SkyWalking调试环境搭建
date: '2020-06-04 20:39:20'
updated: '2020-06-04 20:39:20'
tags: [SkyWalking, 工具, 教程]
permalink: /build-dev-env-for-skywalking
---
![](https://b3logfile.com/bing/20180522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

上一篇文章，主要讲述了如何在window上搭建`SkyWalking`。当然作为一个有理想的程序员🐶，不仅要用，而且还想看看源码，说不定还能贡献个代码，因此搭建个调试环境那将十分必要的。因此本篇文章，将会从克隆源码开始到调试整个过程，分阶段来进行详细讲解`SkyWalking`编译环境的搭建。

# 1.依赖工具

工欲善其事必先利其器，因此在构建之前需要说明一些需要的工具：

* JDK 8：官方提倡
* Maven3
* Git
* npm
* IDEA：官方推荐使用IDEA来进行搭建，虽然说也给了eclipse的说明。但关于eclipse的搭建说明已经好多年没有更新该部分内容了。

# 2. 下载源码

执行如下命令从gihub仓库上拉去源码：

```shell
git clone --recurse-submodules https://github.com/apache/skywalking.git
cd skywalking/
./mvnw clean package -DskipTests

或

git clone https://github.com/apache/skywalking.git
cd skywalking/
git submodule init
git submodule update
./mvnw clean package -DskipTests
```

文件比较大可能需要费点时间，在拉取完毕后导入IDEA会自动使用Maven构建工具进行构建，可能又要持续一段时间，请耐心等待😄

# 3. 编译源码

1. 打开IDEA Terminal执行Maven编译命令：

```shell
 ./mvnw compile -Dmaven.test.skip=true
```

执行完成之后，会生成许多源码文件，因此我们需要将文件所在目录设置为源码目录，便于IDEA在编译时进行识别。

![image-20200604190214826](https://b3logfile.com/file/2020/06/solofetchupload2444691589089203606-dfd95c04.png)

2. 设置源码目录

分别将下边5个目录设置为**源码目录**：

* `apm-protocol/apm-network/target/generated-sources/protobuf`
* `oap-server/server-core/target/generated-sources/protobuf`
* `oap-server/server-receiver-plugin/receiver-proto/target/generated-sources/protobuf`
* `oap-server/exporter/target/generated-sources/protobuf`
* `oap-server/server-configuration/grpc-configuration-sync/target/generated-sources/protobuf`
* `oap-server/oal-grammar/target/generated-sources`

设置方法如下（以`apm-protocol/apm-network/target/generated-sources/protobuf`为例）：

在IDEA上找到该目录-->右键-->Mark Directory as-->Generated Source Root

![image-20200604191456610](https://b3logfile.com/file/2020/06/solofetchupload2960981130487248322-2d36d9f2.png)

设置后对应目录编程蓝色，则表明设置成功。

![image-20200604191613601](https://b3logfile.com/file/2020/06/solofetchupload2950864601117067391-e5ee835a.png)

# 4.启动OAP Server

运行`OAP-server`的`org.apache.skywalking.oap.server.starter.OAPServerStartUp`的`#main(args)`方法,启动SkyWalking OAP Server。

启动后出现控制台打印如下内容，证明启动成功。

![image-20200604192111417](https://b3logfile.com/file/2020/06/solofetchupload7450287582929289975-5593b01a.png)

初次编译时，时间很长，请耐心等待。（我电脑当时第一次编译差不多用了将近8分钟）。

# 5.启动SkyWalking UI

1. 运行 `apm-webapp` 的 `org.apache.skywalking.apm.webapp.ApplicationStartUp` 的 `#main(args)` 方法，启动 SkyWalking UI 。
2. 浏览器打开 `http://127.0.0.1:8080`，出现如下界面
3. ![image-20200604192512037](https://b3logfile.com/file/2020/06/solofetchupload884346280287876773-eb25cc09.png)

# 后记

在搭建过程中遇到的问题：

> Could not extract the Node archive: Could not extract archive

找到报错的压缩包删除之后，重新进行构建

> Failed to execute goal org.apache.maven.plugins:maven-checkstyle-plugin:3. 1

对应位置编码不符合maven的编码规范。我当时报错的文件是gRPC产生的因此我将其删除后，重新构建，然后就成功了。

# 参考

https://github.com/apache/skywalking/blob/master/docs/en/guides/How-to-build.md
