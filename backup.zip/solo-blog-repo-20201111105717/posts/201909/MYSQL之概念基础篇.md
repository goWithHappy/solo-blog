title: MYSQL之概念基础篇
date: '2019-09-14 12:41:34'
updated: '2019-09-14 13:07:48'
tags: [数据库, 教程]
permalink: /mysql1
---
## 1 数据库概述

### 1.1 数据管理技术的产生和发展
数据库技术是应数据库管理任务的需要而产生的。20世纪50年代中期以前，计算机主要是用于科学计算。当时的硬件状况是，外存只有纸带、卡片、磁带，没有磁盘等可以直接存取的设备；软件状况是，没有操作系统，没有管理数据的专门软件；数据处理的方式通常是批处理。对数据的管理主要通过人力来完成，这一阶段我们称为数据的`人工管理阶段`。在这一阶段具有以下特点
* 数据不保存 
由于当时计算机主要用于科学计算，一般不需要将数据进行长期保存，只是在计算某一个题目时，将数据进行输入，用完便撤走。
* 应用程序管理数据  
应用程序所需的数据都有程序设计者区去进行设计、说明、定义和管理，没有相应的软件系统去负责数据的管理工作。
* 数据不共享  
数据是面向应用程序的，一组数据只能对应一个应用程序。当多个应用程序设计多个数据时必须各自相互定义，无法互相利用、互相参照。
* 数据不具有独立性  
数据的物理结构和逻辑结构发生变化后，必须对应用程序作出修改，数据完全依赖于应用程序，数据缺乏独立性。  

20世纪50年代后期到60年代中期，这时候硬件方面已有了磁盘、磁鼓等直接存取的设备；软件方面已经有了专门的数据管理软件，一般称为`文件系统`；处理方法上不仅有批处理，而且能够联机实现处理。这一阶段用`文件管理系统`管理软件具有以下特点：
* 数据可以长期保存  
计算机大量用于数据处理，数据需要长期的留在外存进行增删改查操作。
* 由文件系统长期保存数据  
使用文件系统进行管理解决了数据结构化的问题，但是仍然存在数据`共享性差`，`数据独立性差的缺点`。

20世纪60年代后期以来，计算机管理的对象规模越来越大，应用范围越来越广泛，数据量急剧增加，同时多种应用、多种语言相互覆盖地共享数据集合的要求越来越高。而同时硬件已经有了大容量磁盘，硬件价格下降，软件价格上升。基于以上背景`数据库管理系统`应运而生。  
与人工管理阶段和文件系统相比，数据库的特点主要有以下几个方面：
*  数据结构化  
数据库系统实现整体数据的结构化，这是数据库的主要特征也是数据库系统和文件系统的本质区别。
*  数据共享性高冗余度低且易于扩充  
*  数据独立性高
* 数据由数据库统一组织和管理

然后随着计算机技术的发展，人们需要存储和处理的数据规模越来越大，存储的对象关系和内部结构越来越复杂，传统面型对象的关系型数据库也逐渐表现出来了诸多不足如： 
* 面向机器的语法数据模型  
高度结构化、只能存储离散数据及有限的数据之间关系、语义表达能力弱、缺乏数据抽象。
* 数据类型简单固定  
如:整数、浮点数、字符串、日期等;只支持固定的字符集,不能依据应用所需来扩展其类型集.
* 数据操纵语言与程序语言失配  
SQL是描述性语言，而程序设计语言是指令性语言，不能直接使用关系数据结构。
* 存储和管理的对象有限 
缺乏表达和处理知识的能力 
因此新一代数据技术逐渐出现，当然就现在而言新数据库技术发展并不完善但我们从现在一些发展趋势已经可以隐约猜测出未来新数据技术所具有的特点。
* 应支持数据管理、对象管理和知识管理；必须支持OO数据模型。
* 必须保持和继承第二代数据库系统的技术：即必须保持第二代数据库系统的非过程化数据存取方式和数据独立性。
* 必须对其它系统开放. 数据库系统的开放性表现为:支持数据库语言标准;支持标准网络协议;系统具有良好的可移植性,可连接性,可扩展性和可互操作性。


纵观数据库的发展历史我们不难看出数据库的发展与应用领域和相关技术发展密不可分
![数据库发展与其相关关系示意图](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190914113651.png)

#### 1.1.2 总结
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190914125420.png)

### 1.2 数据模型
数据库按照数据结构来组织、存储和管理数据，实际上，数据库一共有三种模型：`层次模型`、`网状模型`、`关系模型`。
**层次模型**
通过上下级层次结构来组织数据如
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190914125602.jpg)

**网状模型**
数据节点与数据节点直接相互连接，使得整体看起来像数据结构中的图
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190912171632.png)

**关系模型**
把所有数据看做一个二维表格所有的数目都可以通过行号和列号来进行确定
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190912171651.png)

### 1.2 数据类型
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190912171708.png)

### 1.3 SQL
SQL是结构化查询语言的缩写它由以下几个部分构成
**DDL:DATA DEFINE LANGUAGE**
DDL允许用户定义数据，也就是创建表、删除表、修改表结构这些操作（即常见的增删改查操作）
**DML：Data Manipulation Language**
DML为用户提供添加、删除、更新数据的能力，这些是应用程序对数据库的日常操作。
**DQL:Data Query Language**
DQL:允许用户查询数据，这也是通常最频繁的数据库日常操作。
**DCL:Data Control Language**
DCL:数据控制语言 (Data Control Language) 在SQL语言中，是一种可对数据访问权进行控制的指令，它可以控制特定用户账户对数据表、查看表、存储程序、用户自定义函数等数据库对象的控制权。由 GRANT 和 REVOKE 两个指令组成。

### 1.4 数据库演化趋势

![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190914125857.png)

### 1.5 关系
表的每一行称为`记录`（Record），记录是一个逻辑意义上的数据。表的每一列称为`字段`（Column），同一个表的每一行记录都拥有相同的若干字段。
例如`students表的两行记录:`

![students表的两行记录](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190909080659.png)
![对记录和字段的描述](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190909081432.png)
#### 1.5.1 主键
**主键定义：**
`主键`，又称`主码`（英语：`primary key`或`unique key`）。数据库表中对储存数据对象予以唯一和完整标识的数据`列`或`属性`的组合。一个数据表只能有一个`主键`，且`主键`的取值不能缺失，即不能为空值（Null）。
但是一般来唯一和完整标识的数据`列`或`属性`的组合可能不止一个，但是也不是说满足这个条件的属性的组合都可以设置为`主键`。在实际开发和生产的过程中它至少需要满足一个`基本原则`,即不使用和业务相关的字段作为`主键`。因为在实际开发和生产的过程中，`业务逻辑`可能需要频繁修改从而导致与`业务逻辑`相关的字段也可能需要频繁修改，如果一旦以业务相关字段作为`主键`，那么该字段的频繁修改会给表的维护和扩展带来极大的障碍，因此在开发过程中我们不使用任何业务相关的字段作为`主键`，一般情况下则是选择一个和业务逻辑无关的字段作为`主键`。我们常把这个字段命名为id**常见的可作为id字段的类型有：**
1.自增整数类型：数据库会在插入数据时自动为每一条记录分配一个自增整数，这样我们就完全不用担心主键重复，也不用自己预先生成主键；
2.全局唯一GUID类型：使用一种全局唯一的字符串作为主键，类似8f55d96b-8acc-4636-8cb8-76bf8abc2f57。GUID算法通过网卡MAC地址、时间戳和随机数保证任意计算机在任意时间生成的字符串都是不同的，大部分编程语言都内置了GUID算法，可以自己预算出主键。
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20190909084202.png)
**设置主键的操作:**
```sql
ALTER TABLE students ADD PRIMARY KEY(id)
```
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/%E8%AE%BE%E7%BD%AE%E4%B8%BB%E9%94%AE.gif)
当然在建表的过程中也可以设置`主键`，其最终效果与表建立之后再单独设置`主键`效果是一样的。
**建表过程中同时设置主键**
```sql
CREATE TABLE stdudents(
id INT PRIMARY KEY,
class_id INT,
name CHAR(5),
gender CHAR(1),
score DOUBLE
) ;
```
**删除主键的操作:**
```sql
ALTER TABLE students DROP PRIMARY KEY;
```
#### 1.5.2外键
**外键定义：**
如果公共关键字在一个关系中是主关键字，那么这个公共关键字被称为另一个关系的`外键`。
**设置外键:**
```sql
ALTER TABLE students
ADD CONSTRAINT fk_class_id
FOREIGN KEY (class_id)
REFERENCES classes (id);
```
**删除外键：**
```sql
ALTER TABLE students
DROP FOREIGN KEY fk_class_id;
```
### 1.6索引
**索引定义：**
索引是关系数据库中对某一列或多个列的值进行预排序的数据结构
**增加单列索引：**
```sql
ALTER TABLE students
ADD INDEX idx_score (score);
```
**增加多列索引:**
```sql
ALTER TABLE students
ADD INDEX idx_name_score (name, score);
```
**创建唯一索引：**
```sql
ALTER TABLE students
ADD CONSTRAINT uni_name UNIQUE (name);
```
**删除索引:**
```sql
ALTER TABLE students
DROP INDEX idx_name_score (name, score);
或者
DROP INDEX idx_name_score ON students
```
