title: 使用frp搭建内网穿透服务
date: '2020-04-19 16:01:43'
updated: '2020-04-28 21:57:13'
tags: [linux, 教程]
permalink: /learn-frp
---
![](https://img.hacpai.com/bing/20180607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

受制于第三方内网穿透服务的各种限制，加上自己恰好有台云服务器，因此通过 `frp` 搭建了内网穿透服务。

首先，我们给出官方[文档地址](https://github.com/fatedier/frp/blob/master/README_zh.md),便于资深玩家探索新的玩法。但我们要主要注意，**frp 仍然处于开发阶段，未经充分测试与验证**，官方不推荐用于生产环境。但是由于这玩意我是个人使用的，可容忍其部分的不稳定（若出现问题还能提交个 `issue`，何乐而不为）。

给出官方架构图来镇楼。。

![image.png](https://img.hacpai.com/file/2020/04/image-81479655.png)

好，话不多少，我们下边开始搭建。

# 服务器搭建

## 第一步 下载软件包

1. 根据自己**操作系统以及 CPU 架构**选择对应的程序进行下载安装，[下载地址](https://github.com/fatedier/frp/releases)。

> 什么？？不知道怎么看自己 CPU 架构？？

简单来说对于个人 PC，如果 CPU 是 AMD 公司的我们使用后缀为 `amd` 的软件包，如果是 intel 的 CPU 则使用 arm 后缀的软件包。

对于 Linux 来说可以通过如下命令来查看 CPU 的架构。

```shell
lsb_release -a
```

以我的服务器执行结果为例

![image.png](https://img.hacpai.com/file/2020/04/image-ab1ef5b9.png)

明显可以看到操作系统是 **CentOS**，CPU 使用的是 intel 的，或者说是用的是 **amd64** 的软件架构。

对于常用的一些版本我们给出下边的一张图来便于大家寻找对应的软件版本。

![image.png](https://img.hacpai.com/file/2020/04/image-4cf5454d.png)

1. 下载对应的软件包。

以我服务器为例执行如下命令

```shell
cd /usr/
wget https://github.com/fatedier/frp/releases/download/v0.32.1/frp_0.32.1_linux_amd64.tar.gz
tar -xvf frp_0.32.1_linux_amd64.tar.gz
mv frp_0.32.1_linux_amd64.tar.gz frp
rm frp_0.32.1_linux_amd64.tar.gz
```

执行上边一连串命令后我们会在 `/usr` 目录里边看到如下文件夹，里边是关于 frp 的软件包和配置文件。

![image.png](https://img.hacpai.com/file/2020/04/image-1886f8e0.png)

进入 frp，执行 `ls -al` 命令我们可以看到 frp 软件包中的内容如下

![image.png](https://img.hacpai.com/file/2020/04/image-1a1ab607.png)

## 第二步 配置配置文件

默认配置文件如下：

```ini
# frps.ini
[common]
bind_port = 7000
```

如果只是简单使用的话就不用改。如果要改的话，也可以参考官方文档，这里就不再详述。

## 第三步 启动 frps 服务

执行如下命令

```shell
./frps -c ./frps.ini
```

执行结果如下：

![image.png](https://img.hacpai.com/file/2020/04/image-8fd7ee26.png)

如果想要后台以服务形式启动可以执行如下命令。

```shell
nohup ./frps -c ./frps.ini
```

#　客户端使用

首先客户端和服务器软件都在同一文件包下边。

我们首先根据自己的不同需求配置客户端配置文件(frpc.ini)

默认内容如下

```ini
# frpc.ini
[common]
server_addr = x.x.x.x
server_port = 7000

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
```

还是那句话，简单使用无需更改，如果想要通过某个自定义域名访问到该客户端上的资源，需要进行如下配置

```ini
# frpc.ini
[common]
server_addr = x.x.x.x
server_port = 7000

[web]
type = http
local_port = 80
custom_domains = www.yourdomain.com
```

启动客户端，执行如下命令

```shell
./frpc -c ./frpc.ini
```

启动完成之后我们会看到服务器会出现如下结果

![image.png](https://img.hacpai.com/file/2020/04/image-052ba088.png)

服务器端出现如下结果

![image.png](https://img.hacpai.com/file/2020/04/image-5a63a617.png)

以上，穿透服务搭建成功，后续我也会尝试增加一些有趣的玩法，欢迎大家关注。谢谢！！
