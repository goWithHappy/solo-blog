title: 如何在markdown文档中插入emoji表情？
date: '2020-04-26 22:37:27'
updated: '2020-04-28 21:13:06'
tags: [工具, 个人博客]
permalink: /write-emoji-with-markdown
---
![](https://img.hacpai.com/bing/20181105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

今天突然发现 Markdown 文档中，竟然可以插入 emoji 表情，😄:happy:，感觉挺有意思！！

惊了！！😝

特有意思，容我先皮一下。给大家演示一个**喜怒哀乐**

😄 😠☹️😆

```
:happy::angry::frowning::laughing:
```

详细的内容可以参考官网：[点这里:point_left:](https://www.webfx.com/tools/emoji-cheat-sheet/)

![image.png](https://img.hacpai.com/file/2020/04/image-abe8f26c.png)
