title: MYSQL之修改篇
date: '2019-10-01 22:22:15'
updated: '2019-10-01 22:22:15'
tags: [教程, 数据库]
permalink: /sql_change
---
对一个数据库系统来说最常见的无非就是`增删改查`操作，对于查询操作，我们在前边已经详细的叙述了SELECT的使用，下边我们将分三个专题对`增删改`操作进行说明。

## 3.1 INSERT
`INSERT`语句主要用于向数据库表中插入一条或者多条记录。
INSERT语句的基本语法：
```sql
INSERT INTO <表名> (字段1, 字段2, ...) VALUES (值1, 值2, ...);
```
例如向students表中插入一条记录：
```sql
insert into students (class_id,name,gender,score) values(2,'张芳','f',82);
/*显示插入结果*/
select * from students;
```
**运行结果为：**
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191001210924.png)
**注意:**
1. 我们并没有列出`id`字段，也没有列出`id`字段对应的值，这是因为`id`字段是一个自增主键，它的值可以由数据库自己推算出来。此外，如果一个字段有默认值，那么在INSERT语句中也可以不出现。要注意，字段顺序不必和数据库表的字段顺序一致，但值的顺序必须和字段顺序一致。也就是说，可以写INSERT INTO students (score, gender, name, class_id) ...，但是对应的`VALUES`就得变成(80, 'M', '大牛', 2)。
2.如果插入的字段值的顺序与数据库的字段顺序一致时我们并不需要列出属性值(但默认的字段要用default来进行填充不可不写)即可以写成
```sql
insert into students values(default,2,'张芳','f',82);
```

另一方面我们还可以一次性添加多条记录，只需要在`VALUES子句`中指定多个记录值，每个记录是由`(...)`包含的一组值：
```sql
INSERT INTO students (class_id, name, gender, score) VALUES
  (1, '大宝', 'M', 87),
  (2, '二宝', 'M', 81);
 /*显示插入之后的结果*/ 
SELECT * FROM students;
```
**运行结果：**
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191001212131.png)

## 3.2 UPDATE
当我们需要修改数据库表中的记录时我们便需要使用`UPDATE`语句来进行实现,使用`UPDATE`，我们就可以一次更新表中的一条或多条记录。。
`UPDATE`语句的基本语法为：
```sql
UPDATE <表名> SET 字段1=值1, 字段2=值2, ... WHERE ...;
```
例如，我们想更新`students表`id=1的记录的`name`和`score`这两个字段，先写出`UPDATE students SET name='大牛', score=66`，然后在`WHERE子句`中写出需要更新的行的筛选条件`id=1`：
```sql
UPDATE students SET name='大牛', score=66 WHERE id=1;
SELECT * FROM students WHERE id=1;
```
**运行结果：**
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191001213611.png)

注意到`UPDATE`语句的`WHERE`条件和`SELECT`语句的`WHERE`条件其实是一样的，因此完全可以一次更新多条记录：
```sql
UPDATE students SET name='小牛', score=77 WHERE id>=5 AND id<=7;
SELECT * FROM students;
```
**执行结果为：**
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191001214707.png)

**注意：**
`UPDATE`语句在执行的过程可以没有`where`条件进行限制
```sql
UPDATE students SET score=60;
```
但是要注意此时所有表的记录都会被更新，因此在通过`UPDATE`语句进行更新时一定要通过`WHERE`子句筛选出自己所需要更改的字段。

## 3.3 DELETE
如果我们需要删除数据库中的记录我们需要使用`DELETE`语句。

`DELETE`语句的基本语法是：
```sql
DELETE FROM <表名> WHERE ...;
```
比如我们想删除`students`表中`id=1`的记录，就需要这么写：
```sql
DELETE FROM students WHERE id=1;
SELECT * FROM students;
```
**执行结果：**
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191001220939.png)


注意到`DELETE`语句的`WHERE`条件也是用来筛选需要删除的行，因此和`UPDATE`类似，`DELETE`语句也可以一次删除多条记录：
```sql
DELETE FROM students WHERE id>=5 AND id<=7;

SELECT * FROM students;
```
**执行结果：**
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191001221047.png)
最后，要特别小心的是，和`UPDATE`类似，不带`WHERE`条件的`DELETE`语句会删除整个表的数据：
```sql
DELETE FROM students;
```
这时，整个表的所有记录都会被删除。所以，在执行`DELETE`语句时也要非常小心，最好先用`SELECT`语句来测试`WHERE`条件是否筛选出了期望的记录集，然后再用`DELETE`删除。
