title: 解决fcitx输入法在Intellij IDEA开发工具中输入法候选框无法跟随光标移动的问题
date: '2020-09-28 16:01:21'
updated: '2020-09-28 16:01:21'
tags: [教程, java, 工具]
permalink: /fcitx-not-work-in-idea
---
![](https://b3logfile.com/bing/20171211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

在linux平台下使用搜狗输入法在IDEA中输入中文时，输入法候选框总是静止在IDEA的左下角，而不能跟随光标进行移动。虽然不影响输入结果，但很影响输入体验。并且其实网上确实给了一些解决方法，但好多时候，这些解决方法对小白不太友好，因此，此处我尝试站在巨人的肩膀上，对前辈的一些方法进行整合并且给出比较详细的解决步骤。

**系统环境：**

```
KDE Plama Version:5.19.5
KDE Frameworks Version:5.73.0
Kernel Version:5.8.6-1-MANJARO
```

**硬件环境：**

```
处理器：Intel Core i5-8500 cp @3.00GHz
```

# 问题定位

具体问题官方其实七年前就有了（参考https://youtrack.jetbrains.com/issue/JBR-2460），但是比较坑的是官方也一直没有解决这个问题:dog:（此处忍不住吐槽一下哈）。简单来说就是`Idea`的`jre`运行环境一个bug，导致输入法无法定位到鼠标位置。因此，我们要解决该问题必须要修改`JetBrainsRuntime`的运行代码。

# 解决方法

如果只是想快速解决该问题，而对其原理不感兴趣的话，仅仅使用方法1即可。

## 方法1：修改`JetBrainsRuntime`

1. 下载已经修改好的JRE环境

   下载地址1（我有积分）：

   下载地址2(白嫖也很好)：

   ```
   百度云链接: /s/1nUVPhXmgRqPBDe_8MeO-BQ 
   密码: rjg4
   ```
2. 下载完成后解压到任意目录，此处我是解压到了`~/Application`目录下

![test](https://b3logfile.com/file/2020/09/solofetchupload2336681264282715833-107901c1.png)

3. 更改IDEA的启动环境

   修改文件:` home/idea-2020.1/bin/idea.sh (找到你自己的idea的安装路径)`在开头处添加

   `export IDEA_JDK=xport IDEA_JDK=/home/vcjmhg/Application/java-11.0.7-jetbrain`（改成自己的JRE目录）

   ![img](https://b3logfile.com/file/2020/09/solofetchupload1069905368591461482-ade14e8b.gif)

## 方法2：使用path编译`JetBrainsRuntime`

1. 从Github下载JetBrainsRuntime，执行如下代码：

   ```sh
   git clone https://github.com/JetBrains/JetBrainsRuntime.git
   ```
2. 应用patch

   patch 下载地址: https://github.com/prehonor/myJetBrainsRuntime

   ```sh
   #将Path放到JetBrainsRuntime的根目录下
   cd JetBrainsRuntime
   # 应用Patch
   git apply idea.patch
   ```
3. 编译`JetBrainsRuntime`

   这个可以参照官方的提供的方式来进行编译：[戳我](https://github.com/JetBrains/JetBrainsRuntime)。但就我个人尝试的情况来看，使用docker编译或者直接在自己的Arch linux中进行编译都会出现错误。最终可行的方式是使用虚拟机虚拟一个Ububtu 20.0.4的环境进行编译。但需要主要的是给该虚拟分配的内存空间应该大于2G，否则可能出现内存不足，编译错误的情况发生。
4. 参考方法一种的步骤，应该编译好的JRE环境。

# 参考

1. https://blog.csdn.net/qq_37303226/article/details/79640886
2. https://blog.csdn.net/u011166277/article/details/106287587
3. https://bbs.archlinuxcn.org/viewtopic.php?id=10529&p=2
