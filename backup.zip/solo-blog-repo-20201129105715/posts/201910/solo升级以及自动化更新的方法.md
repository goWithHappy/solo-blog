title: solo升级以及自动化更新的方法
date: '2019-10-13 19:17:04'
updated: '2019-10-13 19:17:04'
tags: [solo, 教程]
permalink: /solo_update
---
![](https://img.hacpai.com/bing/20180328.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

使用solo过程总涉及到更新问题，所以就在这里把solo更新的方法总结一下。希望能给小伙伴们一些帮助。如何选择更新方法主要是跟你的部署方式有关，如果你是通过 `docker`方式进行部署，那么你可以还可以通过`docker`方式来进行更新，这也是官方比较推荐的部署方式。如果是通过`jar`包或者`war`包来进行部署，那么更新时同样需要通过该方式来进行。好了闲话少叙进入正题。
## 使用docker更新
**第一步：** 获取最新镜像：

```shell
docker pull b3log/solo:latest
```
执行结果如下：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191012211309.png)
如果有新版本，该命令会自动拉取新镜像，也就是会上边下载的界面。自动更新镜像。
如果当前版本已是最新则会出现下边情况，此时也就不用更新。
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191012210750.png)

**第二步:** 删除原来的容器
第一步虽然获取了最新的镜像，但是我们当前部署的容器却是旧的，需要我们删除之后重新进行部署。
执行`docker ps`查看当前容器的运行情况
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191012212813.png)
此处我部署的solo的容器名称是`www_solo`,所以你在下边删除容器时要更改成自己的solo容器名称

```shell
docker stop www_solo
docker rm www_solo
```
执行结果如下：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191012213105.png)

**第三步：** 重新部署solo容器

```shell
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost
```
* `--env JDBC_PASSWORD="123456" `:  需要将`123456`更改成自己的mysql密码
* ` --server_host=localhost`:  需要将`localhost`更改成自己的域名

执行结果如下：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191012213657.png)
至此solo更新完成
## 通过jar包或者war包更新
此种方式一般都是通过源码来进行部署的，需要重新导入新的solo源码，配置相关信息，然后重新导出。具体的方法可以参考官方给的[文档](https://hacpai.com/article/1493822943172),此处不再详说。

## 通过脚本定期更新
首先，官方给了一个脚本用于更新或者重启，内容如下：
```shell
#!/bin/bash

#
# Solo docker 更新重启脚本
#
# 1. 请注意修改参数
# 2. 可将该脚本加入 crontab，每日凌晨运行来实现自动更新
#

docker pull b3log/solo
docker stop solo
docker rm solo
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost
```
上述脚本说实话用于重启容器可以，但是用于定期更新脚本稍微有点不足，因为定期更新的脚本正常应该检查当前部署的版本是否是最新版本，如果不是才更新。而上边的脚本每次执行都会重新部署，显得开销优点大。下边我们对该脚本进行优化，使其更加合理。
因为docker没有命令直接来获取当前下载的镜像是否是最新版本，但是当我们通过`pull`一个镜像时我们会发现：如果当前本地镜像是最新镜像那么docker就不会从云端下载镜像，运行之后会出现如下结果：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191013142952.png)
如果当前镜像不是新的会出现如下运行结果：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191013143035.png)
因此我们可以借助`grep`，来实现一个更新脚本``
```shell
#!/bin/bash
#
# Solo docker 更新脚本
#
# 1. 请注意修改参数
# 2. 可将该脚本加入 crontab，每日凌晨运行来实现自动更新
#

isUpdate=$(docker pull b3log/solo|grep "Downloaded")

#如果有新版本或者没有安装才会进行更新
if [[ -z  $isUpdate ]] 
then 
	echo This is the latest version
else
	docker stop solo
	docker rm solo
	docker run --detach --name solo --network=host \
	--env RUNTIME_DB="MYSQL" \
       	--env JDBC_USERNAME="root" \
	--env JDBC_PASSWORD="123456" \
	--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
	--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
       	b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost
fi

```
**使用方法：**
```shell
sudo ./docker-update.sh
```
**如果**是最新版会出现如下运行结果：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191013143852.png)
**如果**不是最新版会执行容器删除重启等命令，出现如下运行结果：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191013144801.png)
关于这一点我也想官方发起了`Pull request`希望组织能接受吧。

当然如果希望一劳永逸的解决该问题，我们可以通过`crontab`实现定时更新
**首先**将`docker-update.sh`文件放到`root`目录（当然其他目录）也可以下:
其次执行`crontab -e`进入编辑界面添加如下内容（每天早上1点整执行更新任务）：
```shell
0 1 * * * bash /root/docker-update.sh
```
通过`crontab -l`查看例行任务是否添加成功。
整个过程的执行结果如下图所示：
![](https://raw.githubusercontent.com/goWithHappy/pictureRepo/master/img/20191013150444.png)

## 后记
当然可能个人水平有限，中间难免会出现一些错误，如若发现恳请指出，不胜赐教。如果大家有更好的更新方法或者上边有任何疑问都欢迎大家在留言区提出，谢谢！
