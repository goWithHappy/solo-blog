title: P1005 Spell It Right
date: '2019-09-11 23:33:19'
updated: '2019-09-11 23:33:32'
tags: [算法, c++]
permalink: /Spell_It_Right
---
# P1005 Spell It Right
---  
<strong>原题</strong>  
Given a non-negative integer N, your task is to compute the sum of all the digits of N, and output every digit of the sum in English.

<strong>Input Specification:</strong>
Each input file contains one test case. Each case occupies one line which contains an N (≤10
​100​​ ).

<strong>Output Specification:</strong>
For each test case, output in one line the digits of the sum in English words. There must be one space between two consecutive words, but no extra space at the end of a line.

<strong>Sample Input:</strong>
```
12345
```
<strong>Sample Output:</strong>
```
one five
```
<strong>题目链接:</strong>[https://pintia.cn/problem-sets/994805342720868352/problems/994805519074574336](https://pintia.cn/problem-sets/994805342720868352/problems/994805519074574336)

<strong>题目的中文意思:</strong>  
给定一个非负数N，你的任务是计算出N的各个位数的数字之和，并将其和用英文的形式输出出来，比如  
输入:12345  
输出:one five  

<strong>思路：</strong>
该题的解决思路非常容易，就是的输入整数N的每一位的数字并将其相加得到sum，然后获取sum的每一位，然后将其用英文的形式输出出来。但需要<strong>注意</strong>的是在编程的时候一定要考虑sum=0的情况。  
<strong>代码实现:</strong>  
```c++
#include <cstdio>
#include <iostream>
#include <string>
#define maxN 101
using namespace std;

int main()
{
	string num[10] = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
	long int sum = 0;
	char c;
	while ((c=getchar())!='\n')
	{
		sum += c - '0';
	}
	int s[maxN], length = 0,t=sum;
	while (t!=0)
	{
		s[length++] = t % 10;
		t /= 10;
	}
	//针对sum=0的情况进行处理
	if (sum == 0)
	{
		printf("zero");
		return 0;
	}
	cout << num[s[length - 1]];
	for (int i = length - 2; i >= 0; i--)
	{
		printf(" ");
		cout << num[s[i]];
	}
	//system("pause");
}

```
