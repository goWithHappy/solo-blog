title: 使用deeplabv3+训练自己数据集（迁移学习）
date: '2020-09-27 17:14:11'
updated: '2020-09-27 17:14:11'
tags: [语义分割, 教程, 深度学习]
permalink: /train-own-data-wtih-deeplav3plus
---
![](https://b3logfile.com/bing/20190718.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

在前边一篇文章，我们讲了如何复现论文代码，使用pascal voc 2012数据集进行训练和验证，具体内容可以参考[《deeplab v3+在pascal_voc 2012数据集上进行训练》](https://www.vcjmhg.top/train-deeplabv3-puls-with-pascal-voc-2012)，在本篇文章，我们主要讲述，如何对deeplab v3+进行迁移学习，也即如何使用deeplab v3+算法来训练个人的数据集。

# 1. 数据集准备

首先在开始之前我们先对数据集做一个简单的说明，由于`deeplabv3+`使用的`TensorFlow`框架，并且为了提高训练的速度，因此在训练开始前，需要转换成`tfrecorde`类型的文件来进行训练，因此，我们直接仿照pascal voc 2012数据集的数据结构来制作数据集，这样我们在训练所需图片准备完成之后可以直接复用转换`tfrecorde`的脚本。

## 1.1 标注图片，获取json文件

古人有句话：兵马未动粮草先行，而对深度学习来说，粮草毫无疑问指的是训练的数据，毕竟我们最终的模型都是依靠数据来喂养出来的:dog:！因此选择一个趁手的标注工具很重要，此处我推荐使用`labelme`，标注起来相当方便。

下边我简单说一下`lableme`的**安装方法**(此处建议使用Anconda来实现环境隔离)。

1. 安装Ancodna环境，

   执行如下命令：

   ```shell
   conda create --name=labelme python=2.7（这一步python=*选择自己的Python版本）
   activate labelme
   ```
2. 安装软件与依赖

   ```sh
   conda install pyqt
   pip install labelme
   ```
3. 启动与使用

   ```sh
   activate labelme
   labelme
   ```

启动完成之后可以看到如下界面：

![image-20200927143131553](https://b3logfile.com/file/2020/09/solofetchupload2941671649388356320-01190a6b.png)

标注的时候，将物体用线条框起来即可，例如：

![img](https://b3logfile.com/file/2020/09/solofetchupload4596915048587508095-8c4fcd34.png)

## 1.2 转换json，获取png图片

在图像标注完成之后，在我们对应设置的文件夹下有许多json，这些json文件记录了所标注图片的位置以及图片内容等信息，根据这些信息我们可以转换成训练所需要的mask图（此处是png格式的图片）。

虽然`labelme`中包含`labelme_json_to_dataset`来帮助我们将json图片转成png图片，但是该命令有一个巨大的缺点就是无法实现批量转换，因此需要我们自己写一个批量转换的脚本来辅助转换。

一个简单的转换脚本如下：

```python
import os
#path = 'C:/Users/tj/Desktop/dd'  # path为labelme标注后的.json文件存放的路径
path = 'C:\\Users\\Administrator\\Desktop\\第五次数据集扩充\\labels'
json_file = os.listdir(path)
for file in json_file:
    if(file.split('.')[1]=='json'):
        os.system("labelme_json_to_dataset  %s" % (path + '/' + file))  #
# C:/soft/ev4/venv/Scripts/labelme_json_to_dataset.exe  为labelme_json_to_dataset.exe的路径  path + '/' + file 为读取.json路径
    print(path + '/' + file)
```

通过该脚本每一个json文件都会生成一个以其名字命名的文件夹。

![image-20200927151507055](https://b3logfile.com/file/2020/09/solofetchupload8678523955586622419-5d734036.png)

进入该文件我们可以看到有如下四个文件：

```
img.png
lable.png
label_names.txt
label_viz.png
```

其中第二个文件使我们所需要的用于训练的文件，因此我们需要将该文件整合重命名成其原来json文件的文件名（主要原因是保证和原图的文件名保持一致，便于后续训练）。

从文件夹中提取图片并重命名，我也简单写了一个脚本，可以用于参考，具体内容如下：

```python
import os
path = 'c:\\Users\\Administrator\\Desktop\\temp\\'
output='c:\\Users\\Administrator\\Desktop\\output\\'
fileDirs=os.listdir(path)
for fileDir in fileDirs:
    file=path+fileDir+"\\label.png"
    if(os.path.exists(file)):
        # 输出的文件直接以上层文件夹命名
        end= len(fileDir);
        fileName=fileDir[:end-5]
        os.rename(file,output+fileName+".png")
```

此处处理完成我们便会的到一系列的mask图片，此时我们便可以着手数据集的制作。

## 1.3 制作数据集

正如前边所说，我们在制作数据集的时候仿照的是pascal voc 2012的数据集，因此需要创建预期类似文件夹结构。

1. 我们首先在`models/research/deeplab/datasets`文件夹下为自己的训练集创建一个目录，目录名称即自己的训练集名称。执行如下命令：

```sh
cd ~/models/research/deeplab/datasets
mkdir mydataset
cd mydataset
```

2. 创建与voc数据集类似的文件夹

```sh
# 存放mask文件
mkdir SegmentationClassRaw
# 存放原图
mkdir JPEGImages
# 存放数据集描述文件
mkdir Segmentation
# 存放预训练权重，如不需要预训练权重可不创建
mkdir tf_initial_checkpoint
# 训练权重保存目录
mkdir train_logs
# 评估以及测试结果的生成目录
mkdir vis
# 存放tfrecorde
```

3. 将训练数据放到指定文件夹中：

   1. SegmentationClassRaw：存放mask文件，也就是前边我们所转换提取的png图片
   2. JPEGImages：存放训练集、验证集以及测试集的原始图片
   3. Segmentation:存放数据集描述文件，包含三个文件`train.txt`、t`rainval.txt`、`val.txt`
      1. train.txt:记录训练集的图片名称
      2. trainval.txt：该文件中所记录的内容，后续既会被当做训练集来训练，后续也会被当做验证集来做验证
      3. val.txt用以记录验证集的图片名称
4. 转换成tfrecorde文件。

   在`dataset`目录下，执行如下命令：

   ```python
    python3 "build_voc2012_data.py" \
       --image_folder="${IMAGE_FOLDER}" \
       --semantic_segmentation_folder="${SEMANTIC_SEG_FOLDER}" \
       --list_folder="${LIST_FOLDER}" \
       --image_format="jpg" \
       --output_dir="${OUTPUT_DIR}"  
   ```

```
执行成功后，会在tfrecorde目录下出现如下文件，证明转换成功：
```


![image-20200927164917463](https://b3logfile.com/file/2020/09/solofetchupload8094532195059075997-9d557c69.png)

# 代码修改

### 在`models/research/deeplab/datasets`目录下：

* 在`remove_gt_colormap.py`修改的内容如下:

51行左右，

```python
old_raw_pic=np.array(Image.open(filename))
#原来像素比为0:1:2:3乘以50之后变成0:50:100:150
raw_pic=old_raw_pic*50
return raw_pic
```

* 在`data_generator.py`中修改的内容：

104行左右

```python
 # has changed 增加数据集种类，以及训练验证集合的数量，修改物体类别3+1+1
_MYDATASET = DatasetDescriptor(
    splits_to_sizes={
        'train':392,
        'trainval':98,
        'val':5,
    },
    num_classes=5, # classes+label+ignore_label
    ignore_label=255,
)
#has changed

_DATASETS_INFORMATION = {
    'cityscapes': _CITYSCAPES_INFORMATION,
    'pascal_voc_seg': _PASCAL_VOC_SEG_INFORMATION,
    'ade20k': _ADE20K_INFORMATION,
    'mydataset':_MYDATASET,
}


```

### 在`models/research/deeplab/utils`下

* 在`get_dataset_colormap.py`文件中

在第41行左右，增加训练种类

```python
# has changed
_MYDATASET='mydataset'

```

在388行左右，直接使用pascal的colormap

```python
#has changed
elif dataset == _MYDATASET:
return create_pascal_label_colormap()
```

* 在`train_utils.py`中修改的内容

153行左右，进行训练权重的修改。具体修改参考https://blog.csdn.net/jairana/article/details/83900226

```python
 # has changed
    ignore_weight = 0
    label0_weight = 1  # 对应background，mask中灰度值0
    label1_weight = 10  # 对应a，mask中灰度值1
    label2_weight = 10  # 对应b，mask中灰度值2
    label3_weight = 10 # 对应c,mask中灰度值为3
    not_ignore_mask = tf.to_float(tf.equal(scaled_labels, 0)) * label0_weight + \
    	tf.to_float(tf.equal(scaled_labels, 1)) * label1_weight + \
   		tf.to_float(tf.equal(scaled_labels, 2)) * label2_weight + \
    	tf.to_float(tf.equal(scaled_labels, 3)) * label3_weight + \
   	 	tf.to_float(tf.equal(scaled_labels, ignore_label)) * ignore_weight
   	tf.losses.softmax_cross_entropy(
        train_labels,
        tf.reshape(logits, shape=[-1, num_classes]),
        weights=not_ignore_mask,
        scope=loss_scope)
    # end change

```

228行，排除列表中增加logits

```python
exclude_list = ['global_step','logits']
```

### 在目录`models/research/deeplab/deprecated`下

* `segmentation_dataset.py`文件中

在90行，增加数据类别

```python
#has changed
  _MYDATASET= DatasetDescriptor(
      splits_to_sizes={
          'train':392,
          'trainval':98,
          'val':5,
      },
      num_classes=5,
      ignore_label=255,#background、ignore_label、ignore_label，即label数+2
  )

```

在128行左右，注册新数据集

```python
_DATASETS_INFORMATION = {
     'cityscapes': _CITYSCAPES_INFORMATION,
     'pascal_voc_seg': _PASCAL_VOC_SEG_INFORMATION,
     'ade20k': _ADE20K_INFORMATION,
     # has changed
     'mydataset':_MYDATASET
}
```

### 在`models/research/deeplab/train.py`目录下

158行左右,修改两个参数（使用所有的预训练权重，除了logits，因为如果是自己的数据集，对应的classes不同(这个我们前面已经设置不加载logits),可设置initialize_last_layer=False和last_layers_contain_logits_only=True），可参考https://blog.csdn.net/u011974639/article/details/80948990

```python
# has changed
flags.DEFINE_boolean('initialize_last_layer',False,
                     'Initialize the last layer.')

flags.DEFINE_boolean('last_layers_contain_logits_only', True,
                     'Only consider logits as last layers or not.')

```

# 训练与验证

## 训练

执行如下命令开始进行训练:

```java
python train.py \
    --logtostderr \
    --training_number_of_steps=5000 \
    --train_split="train" \
    --model_variant="xception_65" \
    --atrous_rates=6 \
    --atrous_rates=12 \
    --atrous_rates=18 \
    --output_stride=16 \
    --decoder_output_stride=4 \
    --train_crop_size="513,513" \
    --train_batch_size=12 \
    --dataset="mydataset" \
    --tf_initial_checkpoint='init_models/deeplabv3_pascal_train_aug/model.ckpt' \
    --train_logdir='datasets/mydataset/train_logs' \
    --dataset_dir='datasets/mydataset/tfrecord'
```

## 验证

```java
python eval.py \
    --logtostderr \
    --eval_split="val" \
    --model_variant="xception_65" \
    --atrous_rates=6 \
    --atrous_rates=12 \
    --atrous_rates=18 \
    --output_stride=16 \
    --decoder_output_stride=4 \
    --eval_crop_size="1217,1921" \
    --checkpoint_dir='models/research/deeplab/datasets/mydataset/train_logs' \
    --eval_logdir='datasets/mydataset/eval' \
    --dataset_dir='datasets/mydataset/tfrecord' \
    --max_number_of_evaluations=1
```

# 遇到的如果问题与解决方案

1. 无法找到slim。

   解决方法：进入`models/research`目录下执行

   ```sh
   export PYTHONPATH=$PYTHONPATH:`pwd`:`pwd`/slim:`pwd`/deeplab\
   ```
2. 数据格式不支持，检查是否注册了自己的数据格式
