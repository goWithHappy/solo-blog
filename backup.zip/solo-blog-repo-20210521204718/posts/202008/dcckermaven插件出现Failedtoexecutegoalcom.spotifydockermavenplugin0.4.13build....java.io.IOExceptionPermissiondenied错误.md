title: dccker-maven插件出现"Failed to execute goal com.spotifydocker-maven-plugin0.4.13build....java.io.IOException
  Permission denied"错误
date: '2020-08-25 11:25:35'
updated: '2020-08-25 11:25:35'
tags: [SkyWalking, 工具, java, 教程]
permalink: /solve-docker-maven-permission-deny
---
![](https://b3logfile.com/bing/20191006.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

个人在使用`docker-maven-plugin`来构建镜像的时候出现了permission deny的错误，具体错误日志如下所示：

```sh
[ERROR] Failed to execute goal com.spotify:docker-maven-plugin:0.4.13:build (default-cli) on project tomcat-container: Exception caught: java.util.concurrent.ExecutionException: com.spotify.docker.client.shaded.javax.ws.rs.ProcessingException: java.io.IOException: Permission denied -> [Help 1]'
[ERROR] 
[ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. 
[ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]'
[ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException 
[ERROR] 
[ERROR] After correcting the problems, you can resume the build with the command 
[ERROR] mvn <goals> -rf :tomcat-container
```

按照通常经验来说出现权限不足错误的时候，我们直接切换到root用户下边来执行该问题一般都可以被解决，但是我在实际操作的过程中，发现在切换到root用户后执行该插件会一直被阻塞**（笔者所用操作系统：deepin 20 beta）**。经过苦苦探寻，最终找到了解决该问题的方法。分享于此，希望能够同样遇到该错误的小伙伴以帮助。

# 解决方法

首先，因为以root用户权限执行会出现直接阻塞的问题，因此**考虑能否给普通用户以docker的执行权限**，此时我考虑到可以将当前用户之间添加到`docker的用户组`中，这样问题应该就能解决。因此我执行了如下命令：

```shell
#切换到root用户，如果不想切换可以在执行下边每一个命令的时候，前边都加上sudo
su root 
# 将vcjmhg加入到docker用户组中
usermod -a -G docker vcjmhg 
# 重启dokcer
service docker restart 
#测试 docker能否正常使用
docker ps
```

但是我在执行完前边操作的时候，发现执行dcker ps的时候仍然会出现权限不足的错误，具体报错信息如下：

```sh
Got permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock: Get "http://%2Fvar%2Frun%2Fdocker.sock/v1.40/containers/json": dial unix /var/run/docker.sock: connect: permission denied
```

此时，可能就郁闷了，我已经加入到docker用户组了为何还会出现这种错误？？？

> 原因在于虽然用户加入到了docker用户组，但是当前用户没有切换到docker用户组，所以还是没有权限。

为了解决该问题，我们考虑将当前用户切换到docker用户组中，来执行docker相关操作，也即必行下边命令：

```sh
newgrp docker
```

执行完成之后，我们再执行`docker ps `命令，发现已经可以正常的出现结果了。同时在运行插件，原来的错误也解决了。

## 升级版

经过上边的一系列操作，从某种程度上说，我们已经解决了问题。但这个问题解决的不够**优雅。**

**为何这样说那？**

因为我们每次执行docker命令之前都必须先切换到docker用户组里边，也就是说我们每次在打开一个新的terminal的时候，我们都要先执行`newgrp docker`命令，这对我一个强迫症来说难以接受，因此考虑能否从`docker.sock`文件入手来解决该问题。

说干就干，首先我们先看一下`/var/run/docker.sock`的文件权限

```sh
sudo ls -al /var/run/docker.sock
```

执行结果如下：

```sh
srw-rw---- 1 root docker 0 Aug 25 10:09 /var/run/docker.sock
```

发现普通用户是没有权限操作该文件的，因此考虑修改文件权限，执行如下命令：

```sh
sudo chmod 666 /var/run/docker.sock
```

然后我们重新执行`docker ps`命令发现可以出现正常的结果:

![Screen Capture_select-area_20200825104719](https://b3logfile.com/file/2020/08/solofetchupload6754487363422423857-1b38873e.png)

至此，问题得以圆满解决。
