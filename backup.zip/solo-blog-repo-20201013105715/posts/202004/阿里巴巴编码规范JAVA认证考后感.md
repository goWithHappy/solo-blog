title: 《阿里巴巴编码规范（JAVA）》认证考后感
date: '2020-04-12 19:27:23'
updated: '2020-04-28 21:13:59'
tags: [java, 个人规划]
permalink: /aliyun_java
---
![](https://img.hacpai.com/bing/20180701.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 概述

在 Java 学习过程中愈发感觉到，开发规约的重要性，因此趁着疫情赋闲在家，顺便把编码规范给考了下。考试难度不大，只要把官方给的文档刷一遍，做几套真题，应该都不难通过。

![image.png](https://img.hacpai.com/file/2020/04/image-6c71e4a1.png)

![image.png](https://img.hacpai.com/file/2020/04/image-7f895fe9.png)


# 资料分享

[官方文档地址](https://edu.aliyun.com/course/417/material/?spm=5176.8764728.aliyun-edu-course-tab.2.1cab52bbbMFsj1&previewAs=member)

[搜集的考试题目](https://download.csdn.net/download/Startapi/12315320)
